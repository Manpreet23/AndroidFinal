package com.example.finalexam;

public class Capital {
    private String countryName;
    private String capitalName;
private  String Image;


    public Capital(String countryName, String capitalName,String Image) {
        this.countryName = countryName;
        this.capitalName = capitalName;
        this.Image = Image;
    }

    public String getCountryName() {
        return countryName;
    }

    public String getCapitalName() {
        return capitalName;
    }

    public String getImage() {
        return Image;
    }
}
