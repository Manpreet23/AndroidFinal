package com.example.finalexam;

public class Places {

    private String capitalName;
    private String poi;
    private double price;
    private String image;

    public Places( String capitalName, String poi, double price, String image) {

        this.capitalName = capitalName;
        this.poi = poi;
        this.price = price;
        this.image = image;
    }



    public String getCapitalName() {
        return capitalName;
    }

    public String getPoi() {
        return poi;
    }

    public double getPrice() {
        return price;
    }

    public String getImage() {
        return image;
    }
}
