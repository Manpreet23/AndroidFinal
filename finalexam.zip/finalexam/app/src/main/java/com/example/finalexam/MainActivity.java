package com.example.finalexam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

//https://github.com/Manpreet23/AndroidFinal.git
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener, View.OnClickListener {

    ArrayList<String> countryList= new ArrayList<>();
    ArrayList<Capital> capitalList= new ArrayList<>();
    ArrayList<Places> placeList = new ArrayList<>();
    private Spinner spinner;
TextView tv_capital,tv_amount;
ImageView imageView;
ListView lv_poi;
EditText noOfVistors;
Button btn_book;
    private double total=0;
    private double discountPrice=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

initViews();
        addCountry();
        addCaptal();

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,   android.R.layout.simple_spinner_item, countryList);
        spinner.setAdapter(spinnerArrayAdapter);
        spinner.setOnItemSelectedListener(this);


        lv_poi.setOnItemClickListener(this);
        btn_book.setOnClickListener(this);

    }



    private void initViews() {
        spinner=findViewById(R.id.spinner);
        tv_capital=findViewById(R.id.tv_capital);
        imageView=findViewById(R.id.imageView);
        lv_poi=findViewById(R.id.lv_poi);
        noOfVistors=findViewById(R.id.et_visitor);
        tv_amount=findViewById(R.id.tv_amount);
        btn_book=findViewById(R.id.btn_book);
    }

    private void addCaptal() {
        capitalList.add(new Capital(countryList.get(0),"Ottawa","canada"));
        capitalList.add(new Capital(countryList.get(1),"Washington","usa"));
        capitalList.add(new Capital(countryList.get(2),"London","england"));

    }

    private void addCountry() {
        countryList.add("Canada");
        countryList.add("USA");
        countryList.add("England");
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        tv_capital.setText(capitalList.get(i).getCapitalName());
        int imgID= this.getResources().getIdentifier(capitalList.get(i).getImage(),"drawable",getPackageName());
        imageView.setImageResource(imgID);
placeList.clear();

       if (i==0)
       {
           placeList.add(new Places(capitalList.get(0).getCapitalName(),"Niagra Falls",100.00,"niagra"));
           placeList.add(new Places(capitalList.get(0).getCapitalName(),"CN Towers",30.00,"cn"));
           placeList.add(new Places(capitalList.get(0).getCapitalName(),"Butchart Gardens",30.00,"garden"));
           placeList.add(new Places(capitalList.get(0).getCapitalName(),"Notre Damm Basicila",50.00,"notre"));

       }
       else if (i==1)
       {
           placeList.add(new Places(capitalList.get(1).getCapitalName(),"Statue of liberty",90.00,"liberty"));
           placeList.add(new Places(capitalList.get(1).getCapitalName(),"The White House",60.00,"white"));
           placeList.add(new Places(capitalList.get(1).getCapitalName(),"Time Square",75.00,"square"));

       }
       else if(i==2)
       {
           placeList.add(new Places(capitalList.get(2).getCapitalName(),"Big Ben",30.00,"big"));
           placeList.add(new Places(capitalList.get(2).getCapitalName(),"westminister abbey",25.00,"west"));
           placeList.add(new Places(capitalList.get(2).getCapitalName(),"Hyde Park",15.00,"park"));

       }

        lv_poi.setAdapter(new PlaceAdapter(this,placeList));


    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


        total = placeList.get(i).getPrice();
    }


    @Override
    public void onClick(View view) {
        if (noOfVistors.getText().toString().equals(""))
        {
            Toast.makeText(MainActivity.this,"Please enter count of visitors",Toast.LENGTH_SHORT).show();
        }
        else if (total==0)
        {
            Toast.makeText(MainActivity.this,"Choose place to book",Toast.LENGTH_SHORT).show();

        }
        else if (Integer.parseInt(String.valueOf(noOfVistors.getText()))>15)
        {
           discountPrice = total* Integer.parseInt(noOfVistors.getText().toString())- 1.5*Integer.parseInt(noOfVistors.getText().toString());
       tv_amount.setText(String.valueOf(discountPrice));
        }
        else
        {
            tv_amount.setText(String.valueOf(total* Integer.parseInt(noOfVistors.getText().toString())));
        }

    }
}