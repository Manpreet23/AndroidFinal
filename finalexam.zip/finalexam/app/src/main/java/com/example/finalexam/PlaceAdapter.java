package com.example.finalexam;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class PlaceAdapter extends BaseAdapter {
    private ArrayList<Places> prodList;
    private LayoutInflater inflater;

    public PlaceAdapter(Context context, ArrayList<Places> prodList){
        this.prodList = prodList;
        inflater = LayoutInflater.from(context);

    }
    @Override
    public int getCount() {
        return prodList.size();
    }

    @Override
    public Object getItem(int i) {
        return prodList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view ==null) {
            view = inflater.inflate(R.layout.poi, null);
            holder = new ViewHolder();
            holder.tv_poi = view.findViewById(R.id.tv_poi);
            holder.tv_price = view.findViewById(R.id.tv_price);
            holder.iv_poi = view.findViewById(R.id.iv_poi);
            view.setTag(holder);
        }
        else
            holder = (ViewHolder) view.getTag();

        holder.tv_poi.setText(prodList.get(i).getPoi());
        holder.tv_price.setText(String.valueOf(prodList.get(i).getPrice()));
        int imgID = view.getResources().getIdentifier(prodList.get(i).getImage(),"drawable",inflater.getContext().getPackageName());
        holder.iv_poi.setImageResource(imgID);

        return view;
    }

    static class ViewHolder{
        //create attributes according to the objects in the list_row XML file
        private TextView tv_poi;
        private TextView tv_price;
        private ImageView iv_poi;
    }
}
